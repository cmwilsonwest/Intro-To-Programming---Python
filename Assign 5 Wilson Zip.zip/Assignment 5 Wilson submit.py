
'''**************************************************
Dev: CWilson
Desc: Assingment 5-1 : Working with Dictionaries
The following program takes a file called Todo.txt and loads data from it into memory utilizing dictionaries.
It then asks the user to perform a variety of functions such as, displaying, appending or removing data and
saving the operations to a file.
***************************************************'''

#-- Data --#
# declare variables and constants
# objF = An object that represents a file in the program
# strData = A row of text data from the file
# dicRow = A row of data separated into elements of a dictionary {Task,Priority}
# lstTable = A dictionary that acts as a 'table' of rows
# strMenu = A menu of user options
# strChoice = Capture the user option selection

#-- Input/Output --#
# User can see a Menu (Step 2)
# User can see data (Step 3)
# User can insert or delete data(Step 4 and 5)
# User can save to file (Step 6)
# User can exit script (Step 7)

#-- Processing --#

# Step 1
# When the program starts, load the any data you have
# in a text file called ToDo.txt into a python Dictionary.

# Step 2
# Display a menu of choices to the user, allow the user to select a choice

# Step 3
# Display all the To Do items in the list to user

# Step 4
# Add a new To Do item to the list with a priority of High or Low

# Step 5
# Remove entry from the To Do list

# Step 6
# Save new To Do list to the ToDo.txt file

# Step 7
# Exit program
#-------------------------------


# Script code
objFileDisk = "C:\_PythClas\Todo.txt" # do not define path and default is the same directory the script is in
strData = ""
dicTable = {}
lstTable = []

# Step 1 - Load data from a file
    # When the program starts, load each "row" of data 
    # in "ToDo.txt" into a python Dictionary.
    # Add the each dictionary "row" to a python list "table"

objF = open(objFileDisk, "r")
for l in objF:
    strData = l
    lstInfo =strData.split(",")
    dicTable[lstInfo[0].strip()]=lstInfo[1].strip()
objF.close()

# Step 2 - Display a menu of choices to the user
while(True):
    print ("""
    Menu of Options
    1) Show current data
    2) Add a new item.
    3) Remove an existing item.
    4) Save Data to File
    5) Exit Program
    """)
    strChoice = str(input("Which option would you like to perform? [1 to 5] - "))
    print()#adding a new line

# Step 3 -Show the current items in the list (choice 1)
    if (strChoice.strip() == '1'):
        for strKey, strValue in dicTable.items():
            print(strKey + " (" + strValue + ")")
        continue

# Step 4 - Add a new item to the list/Table (choice 2)
    elif(strChoice.strip() == '2'):
        strTask = str(input("What task would you like to add.... "))
        strPriority = str(input("What priority would you like to assign... high or 1o? "))
        dicTable[strTask] = strPriority
        continue

# Step 5 - Remove an item from the list/Table (choice 3)
    elif(strChoice == '3'):
        for strKey, strValue in dicTable.items():
            print(strKey)
        strKeyRem = input("Which item should be removed?")
        if(strKeyRem in dicTable):
            del dicTable[strKeyRem]
        else:
            print("Please review, that item is not present....")
        continue

# Step 6 - Save tasks to the ToDo.txt file (choice 4)
    elif(strChoice == '4'):
        objF = open(objFileDisk, "w")
        for strKey, strValue in dicTable.items():
            objF.write(strKey + "," + strValue + "\n")
        objF.close()
        continue
# Step 7 - Exit the program (choice 5)
    elif (strChoice == '5'):
        break #and Exit the program

